﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using OnlineStoreAPI.Models;

namespace OnlineStoreAPI.Data
{
    public class OnlineStoreAPIContext : DbContext
    {
        public OnlineStoreAPIContext (DbContextOptions<OnlineStoreAPIContext> options)
            : base(options)
        {
        }

        public DbSet<OnlineStoreAPI.Models.Products> Products { get; set; }

        public DbSet<OnlineStoreAPI.Models.ProductList> ProductList { get; set; }

        public DbSet<OnlineStoreAPI.Models.Carts> Carts { get; set; }
    }
}
