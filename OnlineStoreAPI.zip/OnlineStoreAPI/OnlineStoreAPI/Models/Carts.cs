using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace OnlineStoreAPI.Models
{
    public class Carts
    {
        [Key]
        public int productId { get; set; }
        public int customerId { get; set; }
        public int shoppingId { get; set; }
        public int quantity { get; set; }
    }
}
