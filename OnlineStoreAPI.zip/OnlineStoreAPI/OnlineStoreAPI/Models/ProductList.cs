using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace OnlineStoreAPI.Models
{
    public class ProductList
    {
        [Key]
        public int productId { get; set; }
        public string productName { get; set; }
        public int price { get; set; }
    }
}
